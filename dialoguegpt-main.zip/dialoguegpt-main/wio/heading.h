#define SSID "wifi name" 
#define PASSWORD "wifi password" 
#define my_IPv4 "ipv4 address"
